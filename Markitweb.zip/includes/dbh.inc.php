<?php

$dbServername = "localhost";
$dbUsername = "agenckit_nwadmin";
$dbPassword = "yKn*&qCm21Ix";
$dbName = "agenckit_newsletterdb";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);